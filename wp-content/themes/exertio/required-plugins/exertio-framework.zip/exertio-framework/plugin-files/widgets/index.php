<?php
require FL_PLUGIN_PATH . 'plugin-files/widgets/services-widgets.php';
require FL_PLUGIN_PATH . 'plugin-files/widgets/projects-widgets.php';
require FL_PLUGIN_PATH . 'plugin-files/widgets/employers-widgets.php';
require FL_PLUGIN_PATH . 'plugin-files/widgets/freelancers-widgets.php';